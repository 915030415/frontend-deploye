module.exports = {
  port: 3000,
  database: {
    DATABASE: 'vuesql',
    USER: 'root',
    PASSWORD: 'Duyi_666duyi',
    PORT: '3306',
    HOST: 'localhost',
  },
  jwt_secret: 'ddff0a63e06816ddd7b7d2e2ebc1e40205',
};
