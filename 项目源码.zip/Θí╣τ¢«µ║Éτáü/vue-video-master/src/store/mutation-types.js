export const ADD_USER = 'ADD_USER';
export const INIT_VDIEO_DATA = 'INIT_VDIEO_DATA';
export const INIT_COMMENT_DATA = 'INIT_COMMENT_DATA';
